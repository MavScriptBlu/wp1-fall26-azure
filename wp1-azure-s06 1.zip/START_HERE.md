# Your WP1 Azure access package

Assigned alias: s06
Repository: MavScriptBlu/wp1-fall26-azure
Deployment branch: main
Binding: Recorded by instructor; verify Actions login in class

## Software to have ready before class

- Visual Studio or VS Code, with the .NET SDK version required by the course/project.
- Git, a working GitHub account, and permission to create your own repository.
- Azure CLI, signed in with your school account in the MSTC Labs tenant.
- SQL Server Management Studio on Windows, or the SQL Server client approved for class.
- Docker Desktop or Docker Engine if you will build or test containers locally. Start it and check docker version. The supplied Compose example requires docker compose.
- A browser and access to your school MFA method.

Check dotnet --info, git --version, az version, and (when using local containers) docker version and docker compose version. Resolve installation/restart requirements before class. Match the SDK to the project; do not guess a version from this package.

Official installation references:
- https://dotnet.microsoft.com/download
- https://code.visualstudio.com/
- https://git-scm.com/downloads
- https://learn.microsoft.com/cli/azure/install-azure-cli
- https://learn.microsoft.com/ssms/install/install
- https://docs.docker.com/get-started/get-docker/

## Keep these credentials private

Your three access files belong only to you. Keep them outside your repository and add their names to .gitignore. Never commit passwords, the SQL connection string, or this ZIP. The instructor-wide kit and other students' files are not included.

Use s06-student-access.txt for your portal/resource names and personal SQL login.
Create one repository variable per entry in s06-github-variables.json.
Create the repository Actions SECRET SQL_CONNECTION_STRING from s06-app-connection.txt.
AZURE_CLIENT_ID is for deployment. RUNTIME_CLIENT_ID is for the app. Do not swap them.

## Create your repository and connect in class

1. Create wp1-fall26-azure under your own GitHub account. Include a README so the default branch exists. Do not change your AWS repository.
2. Invite BPMSTC as a collaborator. Send your alias and repository URL to the instructor. The instructor must accept access and bind your actual default branch.
3. Follow the student connection handout: school sign-in, tenant/subscription, own resource group, SQL identity query, then a private uploads test.
4. In Settings > Secrets and variables > Actions, add the individual variables and SQL secret described above.
5. Adapt the files in examples/ to your project. The reference workflow runs deployment jobs only on the repository's current default branch, whether main, master, or another name. Do not add a GitHub Environment or change the default branch without telling the instructor; Azure trust must match.
6. Push your prepared workflow to the default branch. Check Actions login/build/push/deploy separately; test your own application after deployment.

## Reference files

examples/deploy-reference.yml -> .github/workflows/deploy.yml
examples/deploy-app.py -> scripts/deploy-app.py
examples/compose.yml -> compose.yml; adapt build paths and provide Dockerfiles
examples/UploadStore.cs -> adapt to your application's upload service
examples/STUDENT_GUIDE.md -> supporting operations guidance

App port in the deployment reference is 8080. Use the exact frontend/API names in your variables file, Consumption, one container per app, Single revision mode, 0 to 1 replicas, and initially 0.25 CPU / 0.5Gi memory. Keep SQL credentials on the backend.

## Monday connection checkpoint

Everyone will test together in class. Have your alias and repo URL ready. Prove access to your own resource group and database, upload/download/delete a harmless test file in your own uploads container, and report the first failed step with a redacted error. Successful provisioning does not mean your student login or application has already been tested. Do not test with another student's credentials.

Export databases, uploads, and other work before December 21, 2026, Central time.
